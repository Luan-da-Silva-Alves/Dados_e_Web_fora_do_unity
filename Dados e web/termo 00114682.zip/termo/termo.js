// java script source code
var height = 6; // numero de tentativas
var width = 5; // numero de letras da palavra



var row =0; // linha e tentativa atual
var col =0; // letra atual

//controle de finalizar o jogo
var gameOver = false;

//palavra teste
var word = "AULAS";

window.onload = function(){
    initialize();
}


function initialize()//função que cria o jogo inicial
{
//criar o jogo
 for(let r =0; r < height; r++)
 {
     for(let c =0; c < width; c++)
     {
         
       let tile = document.createElement("span");//criar um elemento para configurar a caixa da letra
       tile.id = "jogo-" + r.toString() + "-" + c.toString(); //adicionar um id para localizar este elemento padrão jogo-linha-coluna
       tile.classList.add("tile");//adiconar a classe tile
       tile.innerText ="";// adicionar um texto vazio para poder receber uma letra
      document.getElementById("jogo").appendChild(tile);
     }

 }
 //receber uma letra
 document.addEventListener("keyup", (e) => 
 {
     
    if(gameOver) return;// verificar se o jogo ja finalizou para n exceder nenhum comando

     //alert(e.code);

      //verificar se está em uma posição de receber uma letra
     if("KeyA" <= e.code && e.code <= "KeyZ"){
        if(col < width)
        {
            let currTile = document.getElementById("jogo-" + row.toString() + "-" + col.toString());
            if(currTile.innerText == "")
            {
                currTile.innerText = e.code[3];
            }
            col += 1;
        }
        
     }
     else if(e.code == "Backspace") {
        if(0 < col && col <= width){
            col -=1;
     
            let currTile = document.getElementById("jogo-" + row.toString() + "-" + col.toString());
            currTile.innerText ="";
        }
   }
   else if(e.code == "Enter"){
       update();
       row+=1;
       col=0;
   }
   if(!gameOver && row == height){
       gameOver = true;
       document.getElementById("resposta").innerText = word;

   }
}
 )
}

function update(){
    let correto = 0;
    for(let c =0; c < width; c++){
        let currTile = document.getElementById("jogo-" + row.toString() + "-" + c.toString());
        
        let letter = currTile.innerText;

        if(word[c] == letter)
        {
           currTile.classList.add("correto");//se a posição e a letra estão corretas
           correto +=1;
        }
        else if (word.includes(letter)){
            currTile.classList.add("contem");//se a letra estiver correta
        }
        else{
            currTile.classList.add("errado");//se tudo estiver errado
        }

        if(correto == width){
            gameOver= true;
            document.getElementById("reposta").innerText = word;
        }
    }
}